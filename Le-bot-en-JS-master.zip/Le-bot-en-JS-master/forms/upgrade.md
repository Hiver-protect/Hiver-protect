```
[Lien de votre UserDiag]
**x Votre alim et votre boitier :**
**x Budget :** (A fixer dès le départ) € 
**x Quand voulez-vous acheter :** 
**x Utilisation :** (Gaming / Montage / Stream ...)
**x Jeux joués :** 
**x Logiciels utilisés :** 
**x Pays de résidence :**
```
