**Vous êtes à présent banni du serveur**
Dans 6 mois, vous pourrez effectuer une demande de levée de bannissement que nous étudierons à l'adresse <https://unban.ctrl-f.io>
