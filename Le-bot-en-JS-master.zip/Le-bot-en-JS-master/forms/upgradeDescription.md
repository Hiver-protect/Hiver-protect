Dans le cadre d'une mise à jour de PC, veuillez compléter le mini formulaire ci-dessous et exécuter un diag à l'aide d'**[UserDiag](https://userdiag.com)** afin de connaitre votre matériel actuel. Le but est de vous fournir une mise à jour la mieux adaptée possible. Télécharger l'application, fermer tous vos logiciels en cours d'exécution (le plus grand nombre), lancer l'application et se rendre dans le second onglet **Afficher la configuration de l'ordinateur**, puis cliquer sur le bouton.

**__Nous ne ferons pas d'upgrade si la date d'achat est supérieure à 2 jours, pour des raisons de prix fluctuants & de stock. Merci de poster si et seulement si votre demande respecte le délai.__**

*(Pour les commandes de plus de 1000€, via une demande sur Twitter / Facebook, TopAchat fait une réduction de -5%)*
