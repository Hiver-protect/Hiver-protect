```
**x Budget :** (A fixer dès le départ) €
**x Quand voulez-vous acheter :**
**x Utilisation :** (Gaming / Montage / Stream / Applicatif ...)
**x Critères esthétiques :** (RGB / Fenêtre / Couleur / Taille de boitier ...)
**x Volonté d'OverClocker :** (Oui / Non)
**x Pouvez-vous monter le PC de votre côté ? :** (Oui / J'hésite / Non)
**x Savez-vous installer windows ? :** (Oui / Non)
**x Moyen de connexion à Internet :** Wifi / Ethernet ?
**x Référence de ton écran (si tu en possèdes un) :**
**x Périphériques supplémentaires que vous voulez acheter :** (Écran / Clavier ...)
**x Composants déjà en votre possession :**
**x Jeux joués :**
**x Logiciels utilisés :**
**x Pays de résidence :**
**x Pour vous ou pour quelqu'un d'autre :**
**x Si paiement en plusieurs fois, précisez le (x3, x4, ...) :**
```
