export default (error, shardId) => console.error(`ShardID : ${shardId} | error : ${error}`)
