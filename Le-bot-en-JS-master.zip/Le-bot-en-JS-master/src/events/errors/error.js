export default error => console.error(error)
